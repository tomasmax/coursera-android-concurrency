/** Automatically generated file. DO NOT MODIFY */
package vandy.mooc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}